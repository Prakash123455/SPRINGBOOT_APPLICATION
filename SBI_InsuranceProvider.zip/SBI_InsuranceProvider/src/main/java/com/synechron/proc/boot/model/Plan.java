package com.synechron.proc.boot.model;



import javax.persistence.Column;
//import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="plan")
public class Plan
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int plan_ID;
	
	@Column(name="insurance_provider")
	@NotEmpty(message = "insuranceProvider must not be empty")
	private String insuranceProvider;
	
	@Column(name="cover")
	@NotNull(message="Premium must not be null")
	private double cover;
	
	@Column(name="features_covered")
	@NotEmpty(message = "featuresCovered must not be empty")
	private String featuresCovered;
	
	@Column(name="features_not_covered")
	@NotEmpty(message = "featuresNotCovered must not be empty")
	private String featuresNotCovered;
	
	@Column(name="premium")
	@NotNull(message="Premium must not be null")
	private double premium;
	
	@Column(name="plan_type")
	@NotEmpty(message = "planType must not be empty")
	private String planType;
	
	@Column(name="claim_settlement")
	@NotEmpty(message = "claimSettlement must not be empty")
	private String claimSettlement;
	
	@Column(name = "age")
	private int age;

	public int getPlan_ID() {
		return plan_ID;
	}

	public void setPlan_ID(int plan_ID) {
		this.plan_ID = plan_ID;
	}

	public String getInsuranceProvider() {
		return insuranceProvider;
	}

	public void setInsuranceProvider(String insuranceProvider) {
		this.insuranceProvider = insuranceProvider;
	}

	public double getCover() {
		return cover;
	}

	public void setCover(double cover) {
		this.cover = cover;
	}

	public String getFeaturesCovered() {
		return featuresCovered;
	}

	public void setFeaturesCovered(String featuresCovered) {
		this.featuresCovered = featuresCovered;
	}

	public String getFeaturesNotCovered() {
		return featuresNotCovered;
	}

	public void setFeaturesNotCovered(String featuresNotCovered) {
		this.featuresNotCovered = featuresNotCovered;
	}

	public double getPremium() {
		return premium;
	}

	public void setPremium(double premium) {
		this.premium = premium;
	}

	public String getPlanType() {
		return planType;
	}

	public void setPlanType(String planType) {
		this.planType = planType;
	}

	public String getClaimSettlement() {
		return claimSettlement;
	}

	public void setClaimSettlement(String claimSettlement) {
		this.claimSettlement = claimSettlement;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "Plan [plan_ID=" + plan_ID + ", insuranceProvider=" + insuranceProvider + ", cover=" + cover
				+ ", featuresCovered=" + featuresCovered + ", featuresNotCovered=" + featuresNotCovered + ", premium="
				+ premium + ", planType=" + planType + ", claimSettlement=" + claimSettlement + ", age=" + age + "]";
	}

	        
}

