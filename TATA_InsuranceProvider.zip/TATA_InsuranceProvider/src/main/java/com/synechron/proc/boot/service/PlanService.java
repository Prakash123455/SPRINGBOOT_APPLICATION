
 package com.synechron.proc.boot.service;
 
 import java.util.HashMap;
import java.util.List;


import javax.transaction.Transactional;
 
import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.stereotype.Service;

import com.synechron.proc.boot.exception.CustomizedExceptionHandler;
import com.synechron.proc.boot.exception.NoSuchRecordException;
import com.synechron.proc.boot.model.Plan;
import com.synechron.proc.boot.repo.PlanRepository;

  @Service
  @Transactional 
  public class PlanService extends CustomizedExceptionHandler{
  
  @Autowired 
  private PlanRepository planRepo;
  
  public List<Plan> getAllPlans()
  { 
	  System.out.println("PLan list called");
	  return planRepo.findAll(); 
  }
  
  public void savePlan(Plan plan) { 
	  
	  planRepo.save(plan); 
	  }
  
  public Plan getPlanById(int plan_ID) { 
	  return planRepo.findById(plan_ID).orElseThrow(()-> new NoSuchRecordException("NO SUCH ELEMENT FOUND!!")); 
	  }
  
  public List<Plan> getPlanByAge(int age) {
	//  HashMap<Integer, Integer> hm = new HashMap<>();
	//s  hm.put(1,age);
	  
	  return planRepo.getPlanByAge(age);
  }
  
  public void deletePlanById(int plan_ID) throws NoSuchRecordException{ 
	 planRepo.deleteById(plan_ID);
 
  }
  
  
  
  }
 