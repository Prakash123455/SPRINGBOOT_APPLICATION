package com.synechron.proc.boot.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.synechron.proc.boot.model.Plan;
import com.synechron.proc.boot.service.PlanService;

@RestController
@RequestMapping(path = "/TATA")

public class REST_PlanController
{
	@Autowired  PlanService planService;

	@RequestMapping(path="/plans",method = RequestMethod.GET)
	public List<Plan> getPlans()
	{
		return planService.getAllPlans();
	}

	@RequestMapping(path = "/plans/{plan_ID}" ,method = RequestMethod.GET)
	public Plan getPlanById(@PathVariable int plan_ID) {

		return planService.getPlanById(plan_ID);

	}

	@RequestMapping(path = "/api/plans/{age}",method = RequestMethod.GET)
	public List<Plan> getPlanByAge(@PathVariable(value = "age") int age) {
		return planService.getPlanByAge(age);
	}

	@PostMapping(path="/plans")
	public void addPlan(@Valid @RequestBody Plan plan) {
		
		planService.savePlan(plan);
	}

	@PutMapping(path = "/plans/{plan_ID}")
	public void updatePlan(@RequestBody Plan plan, @PathVariable int plan_ID){
		planService.getPlanById(plan_ID);
		planService.savePlan(plan);
	}

	@DeleteMapping(path = "/plans/{plan_ID}")
	public void deletePlan(@PathVariable int plan_ID) {
		planService.deletePlanById(plan_ID);
	}



}
