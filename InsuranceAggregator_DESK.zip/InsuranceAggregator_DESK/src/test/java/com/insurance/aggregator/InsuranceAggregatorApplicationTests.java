package com.insurance.aggregator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InsuranceAggregatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
