package com.insurance.aggregator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InsuranceAggregatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(InsuranceAggregatorApplication.class, args);
	}

}
