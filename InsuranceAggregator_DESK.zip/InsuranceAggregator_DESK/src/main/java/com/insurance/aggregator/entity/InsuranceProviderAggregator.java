package com.insurance.aggregator.entity;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



@Component
//@Entity
//@Table(name="insurance_provider_aggregator")
@JsonIgnoreProperties(ignoreUnknown = true)
public class InsuranceProviderAggregator  {
	
	@JsonProperty("planID")      //json property should be same as variable name
	@JsonAlias("plan_ID")        //json alias name should be same as the ICIC or SBI or TATA plan id name  	//if in case two of them have diffenert name then @JsonAlias({"plan_ID","insurancePlan_Id"})
	private long planID;
	
	//@Column(name = "plan_provider_name")
	@JsonProperty("planProviderName")
	@JsonAlias("insuranceProvider")
	private String planProviderName;
	
	//@Column(name = "plan_coverage")
	@JsonProperty("planCoverage")
	@JsonAlias("cover")
	private double planCoverage;
	
	//@Column(name = "plan_premium")
	@JsonProperty("planPremium")
	@JsonAlias("premium")
	private double planPremium;
	
	@JsonProperty("age")
	@JsonAlias("age")
	private int age;

	public long getPlanID() {
		return planID;
	}

	public void setPlanID(long planID) {
		this.planID = planID;
	}

	public String getPlanProviderName() {
		return planProviderName;
	}

	public void setPlanProviderName(String planProviderName) {
		this.planProviderName = planProviderName;
	}

	public double getPlanCoverage() {
		return planCoverage;
	}

	public void setPlanCoverage(double planCoverage) {
		this.planCoverage = planCoverage;
	}

	public double getPlanPremium() {
		return planPremium;
	}

	public void setPlanPremium(double planPremium) {
		this.planPremium = planPremium;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "InsuranceProviderAggregator [planID=" + planID + ", planProviderName=" + planProviderName
				+ ", planCoverage=" + planCoverage + ", planPremium=" + planPremium + ", age=" + age + "]";
	}
	
	

	

}
