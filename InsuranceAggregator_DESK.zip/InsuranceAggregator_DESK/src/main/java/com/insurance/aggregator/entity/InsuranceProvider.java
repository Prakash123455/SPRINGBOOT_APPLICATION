package com.insurance.aggregator.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

import lombok.Data;


@Component
@Entity
@Table(name="insurance_provider")
public class InsuranceProvider implements Serializable
{
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy =  GenerationType.AUTO)
	private Long insurance_provider_id;
	@Column
	private String insurance_provider_name;
	
	@Column
	private String url;
	
	@Column
	private String response_type;
	
	@Column 
	private String response;

	public Long getInsurance_provider_id() {
		return insurance_provider_id;
	}

	public void setInsurance_provider_id(Long insurance_provider_id) {
		this.insurance_provider_id = insurance_provider_id;
	}

	public String getInsurance_provider_name() {
		return insurance_provider_name;
	}

	public void setInsurance_provider_name(String insurance_provider_name) {
		this.insurance_provider_name = insurance_provider_name;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getResponse_type() {
		return response_type;
	}

	public void setResponse_type(String response_type) {
		this.response_type = response_type;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "InsuranceProvider [insurance_provider_id=" + insurance_provider_id + ", insurance_provider_name="
				+ insurance_provider_name + ", url=" + url + ", response_type=" + response_type + ", response="
				+ response + "]";
	}

	
	

	
}
